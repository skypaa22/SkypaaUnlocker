#!/system/bin/sh
# Fallback prop spoof for KernelSU/KSU-Next when Zygisk not available.
# Safe late-boot modifications only.

tool=""
if command -v kprop >/dev/null 2>&1 ; then
  tool="kprop"
elif command -v resetprop >/dev/null 2>&1 ; then
  exit 0  # Magisk with Zygisk will handle spoof; skip.
else
  tool="setprop"
fi

sp() { $tool "$1" "$2"; }

# Basic non-critical props (no ro.product.* to avoid bootloops)
sp sys.fps_unlock_allowed 120
sp vendor.display.max_perf_fps 120
sp debug.egl.force_fps 120
sp vendor.fps.unlock 1
