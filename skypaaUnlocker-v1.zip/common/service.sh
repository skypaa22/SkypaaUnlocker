#!/system/bin/sh
# Late service spoof for KernelSU to mimic Z Fold5 identity (optional)
if command -v kprop >/dev/null 2>&1 ; then
  sleep 60
  kprop set ro.product.model "SM-F9460"
  kprop set ro.product.brand "samsung"
fi
