
/*
 * skypaaUniversal.cpp - Zygisk native hook
 * Spoofs Build props & OpenGL strings in target games only.
 */
#include <jni.h>
#include <android/log.h>
#include <string>
#include <dlfcn.h>
#include <GLES/gl.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "skypaaUniversal", __VA_ARGS__)

static const char* TARGET_PKGS[] = {
    "com.tencent.ig",           // PUBG Mobile global
    "com.pubg.imobile",         // PUBG Mobile (KR/JPN)
    "com.mobile.legends",       // MLBB
    "com.ea.gp.fifamobile",     // FC Mobile
    nullptr
};

static bool should_spoof(JNIEnv* env, jobject ctx) {
    jclass cls = env->FindClass("android/app/Application");
    jmethodID mid = env->GetMethodID(cls, "getPackageName", "()Ljava/lang/String;");
    jstring pkg = (jstring)env->CallObjectMethod(ctx, mid);
    const char* c_pkg = env->GetStringUTFChars(pkg, nullptr);
    bool ok = false;
    for (int i = 0; TARGET_PKGS[i]; ++i) {
        if (strcmp(c_pkg, TARGET_PKGS[i]) == 0) { ok = true; break; }
    }
    env->ReleaseStringUTFChars(pkg, c_pkg);
    return ok;
}

// Replace Build.MODEL & BRAND
static void spoof_build(JNIEnv* env) {
    jclass build = env->FindClass("android/os/Build");
    jfieldID f_model = env->GetStaticFieldID(build, "MODEL", "Ljava/lang/String;");
    jfieldID f_brand = env->GetStaticFieldID(build, "BRAND", "Ljava/lang/String;");
    if (f_model && f_brand) {
        jstring model = env->NewStringUTF("SM-F9460");
        jstring brand = env->NewStringUTF("samsung");
        env->SetStaticObjectField(build, f_model, model);
        env->SetStaticObjectField(build, f_brand, brand);
        LOGI("Build spoofed to SM-F9460 / samsung");
    }
}

// Hook glGetString
typedef const GLubyte* (*PFNGLGETSTRINGPROC)(GLenum name);
static PFNGLGETSTRINGPROC real_glGetString = nullptr;

extern "C" const GLubyte* glGetString(GLenum name) {
    if (!real_glGetString) {
        void* handle = dlopen("libGLESv1_CM.so", RTLD_LAZY);
        real_glGetString = (PFNGLGETSTRINGPROC)dlsym(handle, "glGetString");
    }
    if (name == GL_VENDOR)   return (const GLubyte*)"Qualcomm";
    if (name == GL_RENDERER) return (const GLubyte*)"Adreno 740";
    return real_glGetString(name);
}

extern "C" jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("skypaaUniversal loaded");
    return JNI_VERSION_1_6;
}
