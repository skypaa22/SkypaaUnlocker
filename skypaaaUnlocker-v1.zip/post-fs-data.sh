#!/system/bin/sh

echo "⚠️ Modul asli by skypaaa - Dilarang reupload tanpa izin!" > /dev/kmsg
# Universal prop-spoof script – works on Magisk (resetprop) and KernelSU (kprop).
set_tool() {
    if command -v resetprop > /dev/null 2>&1; then
        echo "resetprop"
    elif command -v kprop > /dev/null 2>&1; then
        echo "kprop"
    else
        echo "setprop"
    fi
}

PROP_TOOL=$(set_tool)
sp() { $PROP_TOOL "$1" "$2"; }

# ---- Device identity spoof to Samsung Galaxy Z Fold5 ----
sp ro.product.brand "samsung"
sp ro.product.manufacturer "samsung"
sp ro.product.model "SM-F9460"
sp ro.product.device "z_fold5"
sp ro.product.name "Galaxy Z Fold5"
sp ro.product.marketname "Galaxy Z Fold5"

# ---- Global FPS unlock flags ----
sp sys.fps_unlock_allowed 120
sp vendor.display.max_perf_fps 120
sp debug.egl.force_fps 120
sp vendor.fps.unlock 1

# ---- Game‑specific props ----
# PUBG Mobile
sp vendor.pubgm.fps120 1
sp vendor.pubgm.ultra 1
sp vendor.pubgm.highgfx 1

# Mobile Legends
sp vendor.mlbb.highfps 1
sp vendor.mlbb.maxfps 1

# FC Mobile (optional)
sp vendor.fcmobile.highfps 1
sp vendor.fcmobile.highgfx 1
